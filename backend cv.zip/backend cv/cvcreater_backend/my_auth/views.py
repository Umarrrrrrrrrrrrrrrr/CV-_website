from .serializers import UserProfileSerializers
from rest_framework.response import Response
from rest_framework import  status
from rest_framework.decorators import api_view
from django.contrib.auth.hashers import make_password



# Create your views here.
@api_view(['POST'])
def register_user(request):
    print(request.data)
    #optional: check if the request content type is JSON
    # if request.content_type == 'application/json':
    #     return Response({"error": "Unsupported Media Type"}, status = status.HTTP_415_UNSUPPORTED_MEDIA_TYPE)
    

    serializer = UserProfileSerializers(data= request.data)
    if serializer.is_valid():
           # Hash the password before saving 
        serializer.validated_data['password'] = make_password(serializer.validated_data['password'])
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    #Return detailed errors
    print(serializer.errors)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  