from rest_framework import  serializers
from .models import userProfile
from django.contrib.auth.hashers import make_password

class UserProfileSerializers(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = userProfile
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        validated_data['password'] = make_password(validated_data['password'])
        return super(UserProfileSerializers, self).create(validated_data)